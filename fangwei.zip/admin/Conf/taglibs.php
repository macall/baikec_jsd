<?php
//配置后台系统需要用到的自定义标签库
return array(
	'html'=>'@.TagLib.TagLibHtml',
);

?>